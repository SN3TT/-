@echo off
cd /d "%~dp0"
php -d extension=pdo_sqlite -S localhost:8000 -t public router.php
pause
