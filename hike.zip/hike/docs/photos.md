# Фотографии

В проекте используются локально сохранённые фотографии с Unsplash.
Они иллюстративные и не представляют реальные маршруты каталога.

- Озеро: Alex Moliski,
  https://unsplash.com/photos/a-person-standing-on-a-rock-overlooking-a-lake-f7Goo62pueo
  — файл public/images/lake.jpg.
- Лес: Cody Waters,
  https://unsplash.com/photos/a-dirt-path-in-the-middle-of-a-forest-F3EIEHxy5Jc
  — файл public/images/forest.jpg.
- Горы:
  https://images.unsplash.com/photo-1464822759023-fed622ff2c3b
  — файл public/images/mountains.jpg.

Изображения получены с ограничением ширины 1200–1600 пикселей.
Логотип создан в SVG для этого проекта.
