# Структура базы данных и третья нормальная форма

СУБД — SQLite. Схема находится в `database/schema.sql`.
Во всех соединениях включены внешние ключи: `PRAGMA foreign_keys = ON`.

| Таблица | Первичный ключ | Назначение и связи |
| --- | --- | --- |
| users | id | Имя, уникальный e-mail, хеш пароля, дата регистрации |
| regions | id | Уникальное название региона |
| difficulties | id | Уникальное название сложности |
| routes | id | Маршрут, внешние ключи region_id и difficulty_id |
| article_categories | id | Уникальное название категории статей |
| articles | id | Статья, внешние ключи author_id → users и category_id → article_categories |
| trips | id | План похода, внешние ключи user_id → users и route_id → routes |
| gear_categories | id | Уникальное название группы снаряжения |
| gear | id | Предмет снаряжения, внешний ключ category_id |
| trip_gear | (trip_id, gear_id) | Связь похода и предмета; количество и признак собранности |

```mermaid
erDiagram
    users ||--o{ trips : plans
    users ||--o{ articles : writes
    regions ||--o{ routes : contains
    difficulties ||--o{ routes : describes
    routes ||--o{ trips : used_in
    article_categories ||--o{ articles : contains
    gear_categories ||--o{ gear : contains
    trips ||--o{ trip_gear : includes
    gear ||--o{ trip_gear : used_in
```

## 1НФ

В каждой ячейке хранится одно значение: одна дата, один идентификатор,
одно название. Нет полей со списками идентификаторов или набором вещей через запятую.
Каждый предмет похода хранится отдельной строкой в trip_gear.

## 2НФ

В таблицах с простым первичным ключом все неключевые атрибуты
зависят от идентификатора записи.
У trip_gear ключ составной: (trip_id, gear_id).
Количество и признак собранности относятся именно к предмету в конкретном походе
и зависят от всего ключа, а не от одной его части.

## 3НФ

Нет транзитивных зависимостей неключевых атрибутов от первичного ключа:

- Название региона хранится в regions, а не повторяется в routes и trips.
- Название сложности хранится в difficulties, в routes — только difficulty_id.
- Имя и e-mail пользователя не копируются в trips и articles.
- Категория статьи описана в article_categories.
- Название вещи и её категория не копируются в trip_gear.
- Расстояние и набор высоты принадлежат маршруту и не дублируются в trips.
- Рассчитанная продолжительность, количество собранных позиций и процент
  готовности не сохраняются: они вычисляются из исходных данных.

Основные функциональные зависимости:

- routes.id → title, region_id, difficulty_id, distance_km, ascent_m, description, image.
- trips.id → user_id, route_id, title, trip_date, people, speed, break_minutes, notes, created_at.
- articles.id → author_id, category_id, title, summary, body, image, created_at.
- (trip_id, gear_id) → quantity, packed.

Пример устранённой зависимости: вместо
trips.id → route_id → distance_km в таблице trips хранится только route_id;
distance_km извлекается соединением с routes.

Фотография — атрибут маршрута или статьи. Повторное использование одного файла
не создаёт транзитивной зависимости: по имени фотографии не определяется
название маршрута, его регион или расстояние.

## Целостность

- UNIQUE защищает e-mail и названия справочников от дублирования.
- CHECK ограничивает скорость, число участников, количество вещей и булевы значения.
- FOREIGN KEY не позволяет ссылаться на несуществующий маршрут, автора или предмет.
- Составной PRIMARY KEY запрещает дважды добавить одну вещь в один поход.
- ON DELETE CASCADE удаляет список снаряжения вместе с походом.
- Создание похода с исходным списком вещей выполняется в транзакции.
