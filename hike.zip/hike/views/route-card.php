<article class="route-card" data-route data-name="<?= e(mb_strtolower($route['title'])) ?>" data-region="<?= $route['region_id'] ?>" data-difficulty="<?= $route['difficulty_id'] ?>">
<a class="card-image" href="/routes/<?= $route['id'] ?>"><img src="/images/<?= e($route['image']) ?>" alt="<?= e($route['title']) ?>" loading="lazy"><span class="badge"><?= e($route['difficulty']) ?></span></a>
<div class="card-body"><p class="eyebrow"><?= e($route['region']) ?></p><h3><a href="/routes/<?= $route['id'] ?>"><?= e($route['title']) ?></a></h3>
<div class="route-meta"><span><?= e($route['distance_km']) ?> км</span><span>Подъём: <?= $route['ascent_m'] ?> м</span><a href="/routes/<?= $route['id'] ?>" aria-label="Открыть маршрут <?= e($route['title']) ?>">Подробнее</a></div></div>
</article>
