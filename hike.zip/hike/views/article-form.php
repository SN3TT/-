<section class="container page narrow"><a href="/articles" class="back-link">Журнал</a><h1><?= $editing?'Редактировать статью':'Новая статья' ?></h1><form class="panel form-panel" method="post" action="<?= $editing?'/articles/'.(int)$values['id'].'/edit':'/articles/new' ?>"><?= csrf() ?><?php require ROOT.'/views/errors.php'; ?>
<label>Заголовок<input name="title" minlength="3" maxlength="120" value="<?= e($values['title']??'') ?>" required></label>
<div class="form-grid"><label>Категория<select name="category_id"><?php foreach($categories as $c): ?><option value="<?= $c['id'] ?>" <?= (int)($values['category_id']??1)===$c['id']?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></label>
<label>Обложка<select name="image"><?php foreach(['lake.jpg'=>'Озеро','forest.jpg'=>'Лес','mountains.jpg'=>'Горы'] as $file=>$name): ?><option value="<?= $file ?>" <?= ($values['image']??'lake.jpg')===$file?'selected':'' ?>><?= $name ?></option><?php endforeach; ?></select></label></div>
<label>Краткое описание<textarea name="summary" minlength="10" maxlength="300" rows="2" required><?= e($values['summary']??'') ?></textarea></label>
<label>Текст статьи<textarea name="body" minlength="30" maxlength="20000" rows="14" required><?= e($values['body']??'') ?></textarea></label>
<button class="button" type="submit">Сохранить статью</button></form></section>
