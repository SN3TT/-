<section class="container page"><div class="page-heading"><h1>Рассчитать поход</h1></div><div class="two-col">
<form method="post" action="/calculator" class="panel form-panel"><?= csrf() ?><?php require ROOT.'/views/errors.php'; ?><div class="form-grid">
<label>Расстояние, км<input type="number" name="distance" min="0.1" max="200" step="0.1" value="<?= e($values['distance']) ?>" required></label>
<label>Набор высоты, м<input type="number" name="ascent" min="0" max="10000" value="<?= e($values['ascent']) ?>" required></label>
<label>Скорость, км/ч<input type="number" name="speed" min="1" max="8" step="0.1" value="<?= e($values['speed']) ?>" required></label>
<label>Все привалы, мин<input type="number" name="breaks" min="0" max="600" value="<?= e($values['breaks']) ?>" required></label></div><button class="button" type="submit">Рассчитать время</button>
<p class="small-note">Время = расстояние / скорость + 1 час на каждые 600 м подъёма + привалы. Результат — ориентир для планирования.</p></form>
<aside class="result-panel"><?php if(isset($result)): ?><p class="eyebrow">ВАШЕ ВРЕМЯ В ПУТИ</p><h2><?= hours($result) ?></h2><p>Включая <?= e($values['breaks']) ?> минут на остановки.</p><a class="button light" href="/trips/new">Запланировать поход</a><?php else: ?><h2>Время в пути</h2><p>Введите параметры маршрута,<br>и здесь появится расчёт.</p><?php endif; ?></aside></div></section>
