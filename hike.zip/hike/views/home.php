<section class="hero container">
<div class="hero-content"><h1>Меньше суеты.<br>Больше троп.</h1><p>Найдите маршрут, соберите рюкзак<br>и запланируйте свой следующий поход.</p><a class="button light" href="/routes">Выбрать маршрут </a></div>

</section>
<section class="container intro-strip"><p>Всё для хорошего<br><strong>дня на природе</strong></p><div><span class="step-num">01</span><span>Выберите<br>свою тропу</span></div><div><span class="step-num">02</span><span>Рассчитайте<br>время в пути</span></div><div><span class="step-num">03</span><span>Соберите<br>всё необходимое</span></div></section>
<section class="container section"><div class="section-heading"><div><h2>Маршруты</h2></div><a class="read-link" href="/routes">Все маршруты</a></div><div class="cards"><?php foreach($routes as $route) require ROOT.'/views/route-card.php'; ?></div></section>
<section class="container planner-banner"><div><h2>Калькулятор похода</h2><p>Узнайте, сколько займёт дорога с учётом<br>расстояния, подъёмов и остановок.</p><a class="button" href="/calculator">Рассчитать время</a></div><div class="banner-art"><img src="/images/forest.jpg" alt="Лесная тропа" loading="lazy"></div></section>
<section class="container section"><div class="section-heading"><div><h2>Журнал</h2></div><a class="read-link" href="/articles">Весь журнал</a></div><div class="cards"><?php foreach($articles as $article) require ROOT.'/views/article-card.php'; ?></div></section>
