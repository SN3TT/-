<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Тропа — маршруты, планирование походов и список снаряжения.">
<meta name="csrf-token" content="<?= e($_SESSION['csrf']) ?>">
<title><?= e($title ?? 'Тропа') ?> · Тропа</title>
<link rel="icon" href="/images/logo.svg" type="image/svg+xml">
<link rel="stylesheet" href="/fonts/fonts.css">
<link rel="stylesheet" href="/style.css?v=2">
<link rel="stylesheet" href="/travel-theme.css?v=2">
<script src="/app.js" defer></script>
</head>
<body>
<header class="site-header"><div class="container nav-row">
<a class="brand" href="/"><img src="/images/logo.svg" width="36" height="36" alt="">тропа<span class="brand-dot">.</span></a>
<nav aria-label="Основное меню">
<a <?= str_starts_with($active,'/routes')?'aria-current="page"':'' ?> href="/routes">Маршруты</a>
<a <?= $active==='/calculator'?'aria-current="page"':'' ?> href="/calculator">Калькулятор</a>
<a <?= str_starts_with($active,'/articles')?'aria-current="page"':'' ?> href="/articles">Журнал</a>
<a <?= str_starts_with($active,'/trips')?'aria-current="page"':'' ?> href="/trips">Мои походы</a>
</nav>
<?php if($currentUser): ?>
<div class="account"><span><?= e($currentUser['nickname']) ?></span><form method="post" action="/logout"><?= csrf() ?><button class="text-button" type="submit">Выйти</button></form></div>
<?php else: ?><a class="button small outline" href="/login">Войти </a><?php endif; ?>
</div></header>
<?php if(isset($_SESSION['flash'])): ?><div class="container"><div class="flash" role="status"><?= e($_SESSION['flash']) ?></div></div><?php unset($_SESSION['flash']); endif; ?>
<main><?= $content ?></main>
<footer class="site-footer"><div class="container footer-row"><a class="brand" href="/">тропа.</a><a href="/routes">Найти свой маршрут</a></div></footer>
</body></html>

