<?php
require dirname(__DIR__) . '/src/bootstrap.php';
require ROOT . '/src/actions.php';

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$method = $_SERVER['REQUEST_METHOD'];
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header("Content-Security-Policy: default-src 'self'; img-src 'self'; style-src 'self'; script-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'self'");

if ($method === 'POST') {
    if (!hash_equals($_SESSION['csrf'], input('csrf'))) {
        if (str_starts_with($path, '/api/')) {
            http_response_code(403); header('Content-Type: application/json'); echo json_encode(['error'=>'Обновите страницу и попробуйте снова.']); exit;
        }
        view('error', ['title'=>'Сессия устарела', 'code'=>403], 403);
    }
    actions($path);
}
if ($method !== 'GET') fail(405);

if ($path === '/') view('home', ['title'=>'Пора на тропу', 'routes'=>rows(routeSelect().' ORDER BY r.id LIMIT 3'), 'articles'=>rows('SELECT a.*, c.name AS category FROM articles a JOIN article_categories c ON c.id=a.category_id ORDER BY a.id LIMIT 3')]);
if ($path === '/routes') view('routes', ['title'=>'Маршруты', 'routes'=>rows(routeSelect().' ORDER BY r.id'), 'regions'=>rows('SELECT * FROM regions'), 'difficulties'=>rows('SELECT * FROM difficulties')]);
if (preg_match('~^/routes/(\d+)$~', $path, $m)) {
    $route=one(routeSelect().' WHERE r.id=?', [(int)$m[1]]) ?? fail();
    view('route', ['title'=>$route['title'], 'route'=>$route]);
}
if ($path === '/calculator') view('calculator', ['title'=>'Рассчитать поход', 'values'=>['distance'=>'10','ascent'=>'300','speed'=>'4','breaks'=>'40'], 'errors'=>[]]);
if ($path === '/login' || $path === '/register') {
    if (user()) redirect('/trips');
    view('auth', ['title'=>$path==='/login'?'Вход':'Регистрация', 'register'=>$path==='/register', 'errors'=>[], 'values'=>[]]);
}
if ($path === '/trips') {
    $u=requireUser();
    view('trips', ['title'=>'Мои походы', 'trips'=>rows('SELECT t.*, r.title AS route_title, r.image, r.distance_km, g.name AS region FROM trips t JOIN routes r ON r.id=t.route_id JOIN regions g ON g.id=r.region_id WHERE t.user_id=? ORDER BY t.trip_date DESC,t.id DESC', [$u['id']])]);
}
if ($path === '/trips/new') {
    requireUser();
    $routeId=(int)input('route',$_GET,'1');
    view('trip-form',['title'=>'Новый поход','errors'=>[],'values'=>['route_id'=>$routeId,'title'=>'','trip_date'=>date('Y-m-d'),'people'=>1,'speed'=>4,'break_minutes'=>40,'notes'=>''],'routes'=>rows('SELECT id,title FROM routes'),'editing'=>false]);
}
if (preg_match('~^/trips/(\d+)/edit$~',$path,$m)) {
    $trip=tripForUser((int)$m[1]);
    view('trip-form',['title'=>'Изменить поход','errors'=>[],'values'=>$trip,'routes'=>rows('SELECT id,title FROM routes'),'editing'=>true]);
}
if (preg_match('~^/trips/(\d+)$~',$path,$m)) {
    $trip=tripForUser((int)$m[1]);
    $items=rows('SELECT tg.*, g.name, c.name AS category FROM trip_gear tg JOIN gear g ON g.id=tg.gear_id JOIN gear_categories c ON c.id=g.category_id WHERE tg.trip_id=? ORDER BY c.id,g.id',[$trip['id']]);
    view('trip',['title'=>$trip['title'],'trip'=>$trip,'items'=>$items,'available'=>rows('SELECT g.* FROM gear g WHERE NOT EXISTS (SELECT 1 FROM trip_gear tg WHERE tg.trip_id=? AND tg.gear_id=g.id)',[$trip['id']])]);
}
if ($path === '/articles') view('articles',['title'=>'Журнал','articles'=>rows('SELECT a.*, u.nickname, c.name AS category FROM articles a JOIN users u ON u.id=a.author_id JOIN article_categories c ON c.id=a.category_id ORDER BY a.id DESC')]);
if ($path === '/articles/new') {
    requireUser();
    view('article-form',['title'=>'Новая статья','values'=>[],'errors'=>[],'categories'=>rows('SELECT * FROM article_categories'),'editing'=>false]);
}
if (preg_match('~^/articles/(\d+)/edit$~',$path,$m)) {
    $u=requireUser(); $article=one('SELECT * FROM articles WHERE id=? AND author_id=?',[(int)$m[1],$u['id']]) ?? fail();
    view('article-form',['title'=>'Редактировать статью','values'=>$article,'errors'=>[],'categories'=>rows('SELECT * FROM article_categories'),'editing'=>true]);
}
if (preg_match('~^/articles/(\d+)$~',$path,$m)) {
    $article=one('SELECT a.*, u.nickname, c.name AS category FROM articles a JOIN users u ON u.id=a.author_id JOIN article_categories c ON c.id=a.category_id WHERE a.id=?',[(int)$m[1]]) ?? fail();
    view('article',['title'=>$article['title'],'article'=>$article]);
}
fail();
