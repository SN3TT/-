'use strict';
const filters = document.querySelector('#route-filters');
if (filters) {
  const search = document.querySelector('#route-search');
  const region = document.querySelector('#region-filter');
  const difficulty = document.querySelector('#difficulty-filter');
  function filterRoutes() {
    let count = 0;
    document.querySelectorAll('[data-route]').forEach(card => {
      const visible = card.dataset.name.includes(search.value.trim().toLocaleLowerCase('ru'))
        && (!region.value || card.dataset.region === region.value)
        && (!difficulty.value || card.dataset.difficulty === difficulty.value);
      card.hidden = !visible;
      if (visible) count++;
    });
    document.querySelector('#route-count').textContent = 'Найдено маршрутов: ' + count;
    document.querySelector('#no-routes').hidden = count > 0;
  }
  filters.addEventListener('input', filterRoutes);
  filters.addEventListener('submit', event => event.preventDefault());
  filters.addEventListener('reset', () => requestAnimationFrame(filterRoutes));
}
const checks = [...document.querySelectorAll('[data-gear-url]')];
function updateProgress() {
  const count = checks.filter(input => input.checked).length;
  const label = document.querySelector('#gear-count');
  if (label) label.textContent = count + ' из ' + checks.length;
  const progress = document.querySelector('#gear-progress');
  if (progress) progress.value = count;
}
updateProgress();
checks.forEach(input => input.addEventListener('change', async () => {
  const old = !input.checked;
  const error = document.querySelector('#gear-error');
  error.hidden = true;
  input.disabled = true;
  try {
    const body = new URLSearchParams({
      csrf: document.querySelector('meta[name="csrf-token"]').content,
      packed: input.checked ? '1' : '0'
    });
    const response = await fetch(input.dataset.gearUrl, {method:'POST', body, headers:{Accept:'application/json'}});
    if (!response.ok) throw new Error('Не удалось сохранить отметку. Обновите страницу или попробуйте снова.');
    const data = await response.json();
    if (!data.ok) throw new Error('Не удалось сохранить отметку.');
    updateProgress();
  } catch (e) {
    input.checked = old;
    error.textContent = e.message;
    error.hidden = false;
  } finally { input.disabled = false; }
}));
document.querySelectorAll('form[data-confirm]').forEach(form => {
  form.addEventListener('submit', event => {
    if (!window.confirm(form.dataset.confirm)) event.preventDefault();
  });
});
