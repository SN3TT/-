<?php
declare(strict_types=1);

define('ROOT', dirname(__DIR__));
date_default_timezone_set('Asia/Irkutsk');
if (!is_dir(ROOT . '/storage/sessions')) mkdir(ROOT . '/storage/sessions', 0700, true);
session_save_path(ROOT . '/storage/sessions');
session_start(['cookie_httponly' => true, 'cookie_samesite' => 'Lax', 'cookie_secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'use_strict_mode' => true]);
$_SESSION['csrf'] ??= bin2hex(random_bytes(32));

function db(): PDO {
    static $pdo;
    if (!$pdo) {
        $path = getenv('TROPA_DB') ?: ROOT . '/storage/tropa.sqlite';
        $pdo = new PDO('sqlite:' . $path, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
        $pdo->exec('PRAGMA foreign_keys = ON');
        $pdo->exec('PRAGMA busy_timeout = 5000');
        $pdo->exec(file_get_contents(ROOT . '/database/schema.sql'));
        if (!(int)$pdo->query('SELECT COUNT(*) FROM regions')->fetchColumn()) {
            require ROOT . '/database/seed.php';
            seed($pdo);
        }
    }
    return $pdo;
}
function rows(string $sql, array $params = []): array {
    $q = db()->prepare($sql); $q->execute($params); return $q->fetchAll();
}
function one(string $sql, array $params = []): ?array { return rows($sql, $params)[0] ?? null; }
function run(string $sql, array $params = []): void { $q = db()->prepare($sql); $q->execute($params); }
function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function input(string $key, array $source = null, string $default = ''): string {
    $source ??= $_POST;
    return isset($source[$key]) && is_string($source[$key]) ? trim($source[$key]) : $default;
}
function user(): ?array { return isset($_SESSION['user_id']) ? one('SELECT id, nickname, email FROM users WHERE id=?', [$_SESSION['user_id']]) : null; }
function redirect(string $url): never { header('Location: ' . $url, true, 303); exit; }
function flash(string $text): void { $_SESSION['flash'] = $text; }
function csrf(): string { return '<input type="hidden" name="csrf" value="' . e($_SESSION['csrf']) . '">'; }
function requireUser(): array { $u = user(); if (!$u) { flash('Войдите, чтобы сохранить свой поход.'); redirect('/login'); } return $u; }
function view(string $template, array $data = [], int $status = 200): never {
    http_response_code($status); extract($data, EXTR_SKIP);
    $currentUser = user(); $active = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    ob_start(); require ROOT . '/views/' . $template . '.php'; $content = ob_get_clean();
    require ROOT . '/views/layout.php'; exit;
}
function fail(int $code = 404): never { view('error', ['title' => 'Страница не найдена', 'code' => $code], $code); }
function duration(float $distance, float $speed, int $ascent, int $breaks): int {
    return (int)ceil(($distance / $speed + $ascent / 600) * 60 + $breaks);
}
function hours(int $minutes): string { return intdiv($minutes, 60) . ' ч ' . ($minutes % 60) . ' мин'; }
function routeSelect(): string {
    return 'SELECT r.*, g.name AS region, d.name AS difficulty FROM routes r JOIN regions g ON g.id=r.region_id JOIN difficulties d ON d.id=r.difficulty_id';
}
function tripForUser(int $id): array {
    $u = requireUser();
    return one('SELECT t.*, r.title AS route_title, r.distance_km, r.ascent_m, r.image, g.name AS region FROM trips t JOIN routes r ON r.id=t.route_id JOIN regions g ON g.id=r.region_id WHERE t.id=? AND t.user_id=?', [$id, $u['id']]) ?? fail();
}
