<?php
function actions(string $path): never {
    if ($path==='/register' || $path==='/login') {
        $register=$path==='/register';
        $values=['nickname'=>input('nickname'),'email'=>mb_strtolower(input('email'))];
        $password=input('password');
        $errors=[];
        if (!filter_var($values['email'],FILTER_VALIDATE_EMAIL) || strlen($values['email'])>254) $errors[]='Введите корректный e-mail.';
        if ($register && (mb_strlen($values['nickname'])<2 || mb_strlen($values['nickname'])>40)) $errors[]='Имя должно содержать от 2 до 40 символов.';
        if (strlen($password)<8 || strlen($password)>72) $errors[]='Пароль должен содержать от 8 до 72 байт.';
        if (!$errors && $register) {
            if (one('SELECT id FROM users WHERE email=?',[$values['email']])) $errors[]='Этот e-mail уже зарегистрирован.';
            else {
                run('INSERT INTO users (nickname,email,password_hash) VALUES (?,?,?)',[$values['nickname'],$values['email'],password_hash($password,PASSWORD_DEFAULT)]);
                session_regenerate_id(true); $_SESSION['user_id']=(int)db()->lastInsertId(); $_SESSION['csrf']=bin2hex(random_bytes(32));
                flash('Аккаунт создан. Можно планировать первый поход.'); redirect('/trips');
            }
        }
        if (!$errors && !$register) {
            $u=one('SELECT * FROM users WHERE email=?',[$values['email']]);
            if ($u && password_verify($password,$u['password_hash'])) {
                session_regenerate_id(true); $_SESSION['user_id']=$u['id']; $_SESSION['csrf']=bin2hex(random_bytes(32)); redirect('/trips');
            }
            $errors[]='Неверный e-mail или пароль.';
        }
        view('auth',['title'=>$register?'Регистрация':'Вход','register'=>$register,'values'=>$values,'errors'=>$errors],422);
    }
    if ($path==='/logout') { $_SESSION=[]; session_regenerate_id(true); redirect('/'); }
    if ($path==='/calculator') {
        $values=['distance'=>input('distance'),'ascent'=>input('ascent'),'speed'=>input('speed'),'breaks'=>input('breaks')];
        $errors=[];
        foreach (['distance'=>[0.1,200],'ascent'=>[0,10000],'speed'=>[1,8],'breaks'=>[0,600]] as $key=>$range) {
            if (!is_numeric($values[$key]) || !is_finite((float)$values[$key]) || $values[$key]<$range[0] || $values[$key]>$range[1]) $errors[]='Проверьте значения: расстояние 0,1–200 км, подъём 0–10 000 м, скорость 1–8 км/ч, привалы 0–600 мин.';
        }
        $result=$errors?null:duration((float)$values['distance'],(float)$values['speed'],(int)$values['ascent'],(int)$values['breaks']);
        view('calculator',['title'=>'Рассчитать поход','values'=>$values,'errors'=>array_unique($errors),'result'=>$result],$errors?422:200);
    }
    if ($path==='/trips/new' || preg_match('~^/trips/(\d+)/edit$~',$path,$m)) {
        $u=requireUser(); $editing=$path!=='/trips/new'; $id=$editing?(int)$m[1]:null;
        if ($editing) tripForUser($id);
        $values=[];
        foreach(['title','route_id','trip_date','people','speed','break_minutes','notes'] as $key) $values[$key]=input($key);
        $errors=[];
        if (mb_strlen($values['title'])<2 || mb_strlen($values['title'])>100) $errors[]='Название должно содержать от 2 до 100 символов.';
        if (!one('SELECT id FROM routes WHERE id=?',[$values['route_id']])) $errors[]='Выберите маршрут.';
        $date=DateTimeImmutable::createFromFormat('!Y-m-d',$values['trip_date']);
        if (!$date || $date->format('Y-m-d')!==$values['trip_date']) $errors[]='Укажите корректную дату.';
        foreach(['people'=>[1,50],'break_minutes'=>[0,600]] as $key=>$range) {
            if (filter_var($values[$key],FILTER_VALIDATE_INT)===false || $values[$key]<$range[0] || $values[$key]>$range[1]) $errors[]=$key==='people'?'Количество участников: от 1 до 50.':'Привалы: от 0 до 600 минут.';
        }
        if (!is_numeric($values['speed']) || $values['speed']<1 || $values['speed']>8) $errors[]='Скорость: от 1 до 8 км/ч.';
        if (mb_strlen($values['notes'])>5000) $errors[]='Заметка слишком длинная: максимум 5000 символов.';
        if ($errors) view('trip-form',['title'=>$editing?'Изменить поход':'Новый поход','errors'=>$errors,'values'=>$values+['id'=>$id],'routes'=>rows('SELECT id,title FROM routes'),'editing'=>$editing],422);
        if ($editing) run('UPDATE trips SET title=:title, route_id=:route_id, trip_date=:trip_date, people=:people, speed=:speed, break_minutes=:break_minutes, notes=:notes WHERE id=:id AND user_id=:user_id',$values+['id'=>$id,'user_id'=>$u['id']]);
        else {
            db()->beginTransaction();
            try {
                run('INSERT INTO trips (title,route_id,trip_date,people,speed,break_minutes,notes,user_id) VALUES (:title,:route_id,:trip_date,:people,:speed,:break_minutes,:notes,:user_id)',$values+['user_id'=>$u['id']]);
                $id=(int)db()->lastInsertId();
                run('INSERT INTO trip_gear (trip_id,gear_id) SELECT ?, id FROM gear WHERE id<=11',[$id]);
                db()->commit();
            } catch(Throwable $e) { db()->rollBack(); throw $e; }
        }
        flash($editing?'Поход обновлён.':'Поход сохранён. Теперь можно собрать рюкзак.'); redirect('/trips/'.$id);
    }
    if (preg_match('~^/trips/(\d+)/delete$~',$path,$m)) {
        $trip=tripForUser((int)$m[1]); run('DELETE FROM trips WHERE id=?',[$trip['id']]); flash('Поход удалён.'); redirect('/trips');
    }
    if (preg_match('~^/api/trips/(\d+)/gear/(\d+)$~',$path,$m)) {
        header('Content-Type: application/json; charset=UTF-8');
        $u=user();
        if (!$u) { http_response_code(401); echo json_encode(['error'=>'Войдите снова.']); exit; }
        $trip=one('SELECT id FROM trips WHERE id=? AND user_id=?',[(int)$m[1],$u['id']]);
        $item=$trip?one('SELECT * FROM trip_gear WHERE trip_id=? AND gear_id=?',[$trip['id'],(int)$m[2]]):null;
        if (!$item) { http_response_code(404); echo json_encode(['error'=>'Запись не найдена.']); exit; }
        $packed=input('packed');
        if (!in_array($packed,['0','1'],true)) { http_response_code(422); echo json_encode(['error'=>'Неверное значение.']); exit; }
        run('UPDATE trip_gear SET packed=? WHERE trip_id=? AND gear_id=?',[(int)$packed,$trip['id'],(int)$m[2]]);
        echo json_encode(['ok'=>true]); exit;
    }
    if (preg_match('~^/trips/(\d+)/gear$~',$path,$m)) {
        $trip=tripForUser((int)$m[1]); $gearId=(int)input('gear_id'); $quantity=filter_var(input('quantity'),FILTER_VALIDATE_INT);
        if ($quantity===false || $quantity<1 || $quantity>100 || !one('SELECT id FROM gear WHERE id=?',[$gearId])) {
            flash('Выберите вещь и количество от 1 до 100.'); redirect('/trips/'.$trip['id']);
        }
        run('INSERT INTO trip_gear (trip_id,gear_id,quantity) VALUES (?,?,?) ON CONFLICT(trip_id,gear_id) DO UPDATE SET quantity=excluded.quantity',[$trip['id'],$gearId,$quantity]);
        redirect('/trips/'.$trip['id']);
    }
    if (preg_match('~^/trips/(\d+)/gear/(\d+)/delete$~',$path,$m)) {
        $trip=tripForUser((int)$m[1]); run('DELETE FROM trip_gear WHERE trip_id=? AND gear_id=?',[$trip['id'],(int)$m[2]]); redirect('/trips/'.$trip['id']);
    }
    if ($path==='/articles/new' || preg_match('~^/articles/(\d+)/edit$~',$path,$m)) {
        $u=requireUser(); $editing=$path!=='/articles/new'; $id=$editing?(int)$m[1]:null;
        if ($editing && !one('SELECT id FROM articles WHERE id=? AND author_id=?',[$id,$u['id']])) fail();
        $values=[];
        foreach(['title','summary','body','category_id','image'] as $key) $values[$key]=input($key);
        $errors=[];
        foreach(['title'=>[3,120],'summary'=>[10,300],'body'=>[30,20000]] as $key=>$range) {
            if (mb_strlen($values[$key])<$range[0] || mb_strlen($values[$key])>$range[1]) $errors[]=['title'=>'Заголовок: 3–120 символов.','summary'=>'Краткое описание: 10–300 символов.','body'=>'Текст статьи: 30–20 000 символов.'][$key];
        }
        if (!one('SELECT id FROM article_categories WHERE id=?',[$values['category_id']])) $errors[]='Выберите категорию.';
        if (!in_array($values['image'],['lake.jpg','forest.jpg','mountains.jpg'],true)) $errors[]='Выберите фотографию.';
        if ($errors) view('article-form',['title'=>$editing?'Редактировать статью':'Новая статья','values'=>$values+['id'=>$id],'errors'=>$errors,'categories'=>rows('SELECT * FROM article_categories'),'editing'=>$editing],422);
        if ($editing) run('UPDATE articles SET title=:title, summary=:summary, body=:body, category_id=:category_id, image=:image WHERE id=:id AND author_id=:author_id',$values+['id'=>$id,'author_id'=>$u['id']]);
        else { run('INSERT INTO articles (author_id,title,summary,body,category_id,image) VALUES (:author_id,:title,:summary,:body,:category_id,:image)',$values+['author_id'=>$u['id']]); $id=(int)db()->lastInsertId(); }
        flash('Статья сохранена.'); redirect('/articles/'.$id);
    }
    if (preg_match('~^/articles/(\d+)/delete$~',$path,$m)) {
        $u=requireUser();
        if (!one('SELECT id FROM articles WHERE id=? AND author_id=?',[(int)$m[1],$u['id']])) fail();
        run('DELETE FROM articles WHERE id=?',[(int)$m[1]]); flash('Статья удалена.'); redirect('/articles');
    }
    fail();
}
