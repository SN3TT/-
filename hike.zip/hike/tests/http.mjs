import assert from 'node:assert/strict';
const base = process.env.TROPA_URL || 'http://localhost:8017';
class Browser {
  cookie = '';
  token = '';
  async request(path, data) {
    const response = await fetch(base + path, {
      method: data === undefined ? 'GET' : 'POST',
      redirect: 'manual',
      headers: {cookie: this.cookie},
      body: data === undefined ? undefined : new URLSearchParams({csrf: this.token, ...data})
    });
    for (const value of response.headers.getSetCookie()) {
      if (value.startsWith('PHPSESSID=')) this.cookie = value.split(';')[0];
    }
    const html = await response.text();
    const token = html.match(/name="csrf-token" content="([^"]+)"/);
    if (token) this.token = token[1];
    return {status: response.status, html, location: response.headers.get('location')};
  }
}
const guest = new Browser();
for (const path of ['/', '/routes', '/routes/1', '/articles', '/articles/1', '/calculator', '/login', '/register']) {
  const r = await guest.request(path);
  assert.equal(r.status, 200, path);
  assert.doesNotMatch(r.html, /Fatal error|Warning:|Deprecated:/);
}
for (const path of ['/missing', '/routes/999', '/articles/999', '/storage/tropa.sqlite', '/src/bootstrap.php']) {
  assert.equal((await guest.request(path)).status,404,path);
}
for (const path of ['/style.css','/app.js','/images/lake.jpg','/images/mountains.jpg','/images/forest.jpg']) {
  assert.equal((await fetch(base+path)).status,200,path);
}
let r = await guest.request('/calculator', {distance:'10',ascent:'600',speed:'5',breaks:'30'});
assert.equal(r.status,200); assert.match(r.html,/3 ч 30 мин/);
assert.equal((await guest.request('/calculator',{distance:'10',ascent:'0',speed:'0',breaks:'30'})).status,422);
assert.equal((await guest.request('/calculator',{csrf:'bad',distance:'10'})).status,403);
assert.equal((await guest.request('/trips')).location,'/login');

const a = new Browser();
await a.request('/register');
const email = 'test-'+Date.now()+'@example.com';
r = await a.request('/register',{nickname:'Тестовый турист',email,password:'TestPassword123'});
assert.equal(r.location,'/trips');
await a.request('/trips');
const trip = {title:'Поход <script>alert(1)</script>',route_id:'1',trip_date:'2027-06-10',people:'3',speed:'4',break_minutes:'40',notes:'Сбор у вокзала'};
r = await a.request('/trips/new',trip);
assert.equal(r.status,303); assert.match(r.location,/^\/trips\/\d+$/);
const tripUrl = r.location;
r = await a.request(tripUrl);
assert.match(r.html,/&lt;script&gt;alert/);
assert.doesNotMatch(r.html,/<script>alert/);
assert.match(r.html,/3 ч 6 мин/);
const gearUrl = r.html.match(/data-gear-url="([^"]+)"/)[1];
assert.equal((await a.request(gearUrl,{packed:'1'})).status,200);
r=await a.request(tripUrl);
assert.match(r.html,/data-gear-url="[^"]+" checked/);
assert.equal((await a.request(tripUrl+'/edit',{...trip,title:'Обновлённый поход'})).status,303);
assert.match((await a.request(tripUrl)).html,/Обновлённый поход/);
assert.equal((await a.request('/trips/new',{...trip,people:'0'})).status,422);
assert.equal((await a.request('/trips/new',{...trip,trip_date:'2027-02-30'})).status,422);
assert.equal((await a.request(tripUrl+'/gear',{gear_id:'12',quantity:'2'})).status,303);
assert.match((await a.request(tripUrl)).html,/Трекинговые палки/);

const b = new Browser(); await b.request('/register');
assert.equal((await b.request('/register',{nickname:'Другой турист',email:'other-'+email,password:'TestPassword123'})).status,303);
await b.request('/trips');
assert.equal((await b.request(tripUrl)).status,404);
assert.equal((await b.request(tripUrl+'/edit',trip)).status,404);
assert.equal((await b.request(tripUrl+'/delete',{})).status,404);
assert.equal((await b.request(gearUrl,{packed:'0'})).status,404);

const article = {title:'Тестовая статья',summary:'Описание тестовой статьи для проверки.',body:'Проверка сохранения текста статьи и отображения автора из таблицы пользователей.',category_id:'1',image:'forest.jpg'};
r=await a.request('/articles/new',article);
assert.equal(r.status,303); const articleUrl=r.location;
r=await a.request(articleUrl);
assert.match(r.html,/Автор: Тестовый турист/);
assert.equal((await b.request(articleUrl+'/edit',article)).status,404);
assert.equal((await b.request(articleUrl+'/delete',{})).status,404);
assert.equal((await a.request(articleUrl+'/edit',{...article,title:'Исправленная статья'})).status,303);
assert.match((await a.request(articleUrl)).html,/Исправленная статья/);
assert.equal((await a.request('/articles/new',{...article,body:'мало'})).status,422);
assert.equal((await a.request(articleUrl+'/delete',{})).status,303);
assert.equal((await a.request(articleUrl)).status,404);
assert.equal((await a.request(tripUrl+'/delete',{})).status,303);
assert.equal((await a.request(tripUrl)).status,404);
assert.equal((await a.request('/logout',{})).status,303);
await a.request('/login');
assert.equal((await a.request('/login',{email,password:'Incorrect123'})).status,422);
assert.equal((await a.request('/login',{email,password:'TestPassword123'})).location,'/trips');
console.log('PASS: pages, assets, calculator, validation, CSRF, registration, login, trip CRUD, gear persistence, article CRUD, authors, escaping and owner access.');
